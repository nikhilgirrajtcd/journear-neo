package com.journear.app.map.utils;

public interface DataPointInterface {
    /**
     * @return the x value
     */
    public double getX();

    /**
     * @return the y value
     */
    public double getY();
}