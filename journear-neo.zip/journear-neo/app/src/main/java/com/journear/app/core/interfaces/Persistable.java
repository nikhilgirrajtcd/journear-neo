package com.journear.app.core.interfaces;

public interface Persistable {
    int id = -1;
}
