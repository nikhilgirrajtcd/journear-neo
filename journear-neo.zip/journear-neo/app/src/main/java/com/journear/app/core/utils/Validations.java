package com.journear.app.core.utils;

public class Validations {
}
