package com.journear.app.core.entities;

public class JourneyPreference {

}
