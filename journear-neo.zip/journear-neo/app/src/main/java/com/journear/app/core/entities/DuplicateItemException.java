package com.journear.app.core.entities;

public class DuplicateItemException extends Exception {
}
