package com.journear.app.map.model.listeners;

/**
 * This file is part of PocketMaps
 * <p/>
 * Author: Paul Kashofer (Austria) Starcommander@github.com
 */
public interface OnProgressListener {
    void onProgress(int progress);
}
