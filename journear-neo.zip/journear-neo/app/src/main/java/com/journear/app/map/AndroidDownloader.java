package com.journear.app.map;

import com.graphhopper.util.Downloader;

public class AndroidDownloader extends Downloader {
    public AndroidDownloader() {
        super("GraphHopper Android");
    }
}
